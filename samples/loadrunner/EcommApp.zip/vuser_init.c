// Maximum memory that can be allocated for local variables is 64k
char buffer[65536];
int bytes_read;

AddAuthorizationHeader()
{
	char *access_token;
	
	access_token = lr_eval_string("{c_AccessToken}");
	
	if (access_token != NULL && strcmp(access_token, "") != 0 && strcmp(access_token, "{c_AccessToken}") != 0)
	{
		web_add_header("Authorization", "{c_AccessToken}");
	}
}

ReadTemplate(char *filename, char *output_param)
{
	long file;
	file = fopen(filename, "r");
	
	memset(&buffer, 0, sizeof(buffer));
	bytes_read = fread(buffer, 1, sizeof(buffer) - 1, file);
	buffer[bytes_read] = '\0';
	fclose(file);
	
	lr_save_string(lr_eval_string(buffer), output_param);
}

vuser_init()
{
	return 0;
}

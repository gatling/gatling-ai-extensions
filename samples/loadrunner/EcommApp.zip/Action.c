// Web endpoints

HomePage()
{
	int status;

	lr_start_transaction("Home page");

	web_url("Home",
		"URL={HOST_URL}",
		"Resource=0",
		"RecContentType=text/html",
		"Snapshot=t10.inf",
		"Mode=HTML",
		LAST);

	status = web_get_int_property(HTTP_INFO_RETURN_CODE);

	// Accept both OK (200) and Not Modified (304) statuses
	if (status == 200 || status == 304)
	{
		lr_end_transaction("Home page", LR_PASS);
	}
	else
	{
		lr_end_transaction("Home page", LR_FAIL);
	}
}


LoginPage()
{
	int status;

	lr_start_transaction("Login page");

	web_url("Login page",
		"URL={HOST_URL}/login",
		"Resource=0",
		"RecContentType=text/html",
		"Snapshot=t11.inf",
		"Mode=HTML",
		LAST);
	
	status = web_get_int_property(HTTP_INFO_RETURN_CODE);

	// Accept both OK (200) and Not Modified (304) statuses
	if (status == 200 || status == 304)
	{
		lr_end_transaction("Login page", LR_PASS);
	}
	else
	{
		lr_end_transaction("Login page", LR_FAIL);
	}
}

// API endpoints

Session()
{
	int status;

	lr_start_transaction("Session");

	web_reg_save_param_json(
		"ParamName=c_SessionId",
		"QueryString=$.sessionId",
		SEARCH_FILTERS,
		"Scope=Body",
		LAST);

	web_url("Session",
		"URL={API_URL}/session",
		"Resource=0",
		"RecContentType=application/json",
		"Referer={HOST_URL}/",
		"Snapshot=t20.inf",
		"Mode=HTML",
		LAST);

	status = web_get_int_property(HTTP_INFO_RETURN_CODE);

	if (status == 200)
	{
		lr_end_transaction("Session", LR_PASS);
	}
	else
	{
		lr_end_transaction("Session", LR_FAIL);
	}
}

Products()
{
	int status;

	lr_start_transaction("Products");

	AddAuthorizationHeader();

	web_url(lr_eval_string("Product page: {p_PageIndex}"),
		"URL={API_URL}/products?page={p_PageIndex}",
		"Resource=0",
		"RecContentType=application/json",
		"Referer={HOST_URL}/",
		"Snapshot=t21.inf",
		"Mode=HTML",
		LAST);
 
	status = web_get_int_property(HTTP_INFO_RETURN_CODE);

	if (status == 200)
	{
		lr_end_transaction("Products", LR_PASS);
	}
	else
	{
		lr_end_transaction("Products", LR_FAIL);
	}
}

Login()
{
	int status;

	lr_start_transaction("Login");

	web_reg_save_param_json(
		"ParamName=c_AccessToken",
		"QueryString=$.accessToken",
		SEARCH_FILTERS,
		"Scope=Body",
		LAST
	);

	AddAuthorizationHeader();

	web_submit_data("Login",
		"Action={API_URL}/login",
		"Method=POST",
		"RecContentType=application/json",
		"Referer={HOST_URL}/login",
		"Snapshot=t22.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=username", "Value={p_Username}", ENDITEM,
		"Name=password", "Value={p_Password}", ENDITEM,
		LAST);

	status = web_get_int_property(HTTP_INFO_RETURN_CODE);

	if (status == 200)
	{
		lr_end_transaction("Login", LR_PASS);
	}
	else
	{
		lr_end_transaction("Login", LR_FAIL);
		lr_error_message("Login failed");
		lr_exit(LR_EXIT_ACTION_AND_CONTINUE, LR_FAIL);
	}
}

Search()
{
	int status;

	lr_start_transaction("Search");

	AddAuthorizationHeader();

	web_reg_save_param_json(
		"ParamName=c_Products",
		"QueryString=$.products",
		SEARCH_FILTERS,
		"Scope=Body",
		LAST
	);

	web_url("Search",
		"URL={API_URL}/products?search={p_ProductName}",
		"Resource=0",
		"RecContentType=application/json",
		"Referer={HOST_URL}/",
		"Snapshot=t23.inf",
		"Mode=HTML",
		LAST);

	status = web_get_int_property(HTTP_INFO_RETURN_CODE);

	if (status == 200)
	{
		lr_end_transaction("Search", LR_PASS);
	}
	else
	{
		lr_end_transaction("Search", LR_FAIL);
	}
}

AddToCart()
{
	int status;

	lr_start_transaction("Add to cart");
	
	AddAuthorizationHeader();
	
	lr_eval_json("Buffer={c_Products}",
		"JsonObject=j_Products",
		LAST);
	lr_json_get_values("JsonObject=j_Products",
		"ValueParam=p_CartItem",
		"QueryString=$[0]",
		LAST);
	
	ReadTemplate("cart.json", "p_CartBody");

	web_custom_request("Add to cart",
		"URL={API_URL}/cart",
		"Method=POST",
		"Resource=0",
		"RecContentType=application/json",
		"Referer={HOST_URL}/",
		"Snapshot=t24.inf",
		"TargetFrame=",
		"Mode=HTML",
		"Body={p_CartBody}",
		LAST);

	status = web_get_int_property(HTTP_INFO_RETURN_CODE);

	if (status == 200)
	{
		lr_end_transaction("Add to cart", LR_PASS);
	}
	else
	{
		lr_end_transaction("Add to cart", LR_FAIL);
	}
}

Checkout()
{
	int status;

	lr_start_transaction("Checkout");

	AddAuthorizationHeader();

	web_custom_request("Checkout",
		"URL={API_URL}/checkout",
		"Method=POST",
		"Resource=0",
		"RecContentType=application/json",
		"Referer={HOST_URL}/",
		"Snapshot=t25.inf",
		"TargetFrame=",
		"Mode=HTML",
		"Body={p_CartBody}",
		LAST);

	status = web_get_int_property(HTTP_INFO_RETURN_CODE);

	if (status == 200)
	{
		lr_end_transaction("Checkout", LR_PASS);
	}
	else
	{
		lr_end_transaction("Checkout", LR_FAIL);
	}
}

Action()
{
	lr_start_transaction("Home anonymous"); {

		HomePage();
		Session();
		
		lr_save_int(0, "p_PageIndex");
		
		Products();

	}

	lr_end_transaction("Home anonymous", LR_AUTO);
	
	lr_think_time(10);
	
	lr_start_transaction("Authenticate"); {
	
		LoginPage();
		
		lr_think_time(10);
		
		Login();

	}
	
	lr_end_transaction("Authenticate", LR_AUTO);

	lr_start_transaction("Home authenticated"); {

		HomePage();
		Products();
		
		lr_think_time(10);
		
		Search();

	}

	lr_end_transaction("Home authenticated", LR_AUTO);
		
	lr_think_time(10);
	
	lr_start_transaction("Cart"); {

		AddToCart();

	}

	lr_end_transaction("Cart", LR_AUTO);
		
	lr_think_time(10);
	
	lr_start_transaction("Buy"); {

		Checkout();

	}

	lr_end_transaction("Buy", LR_AUTO);

	return 0;
}
